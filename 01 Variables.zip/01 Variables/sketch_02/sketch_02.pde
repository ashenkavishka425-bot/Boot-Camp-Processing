void setup()
{
  size(400, 200);
  fill(0);
}
void draw()
{
  background(255);
  String welcomeMessage = "Hello from Bootcamp";
  textAlign(CENTER, CENTER);
  text(welcomeMessage, width / 2, height / 2);
}
