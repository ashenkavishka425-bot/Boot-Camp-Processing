void setup()
{
  size(400, 400);
  noStroke();
}
void draw()
{
  color skyColour    = color(157, 238, 247);
  color groundColour = color(156, 245, 170);
  color leafColour   = color(82, 144, 97);
  color trunkColour  = color(95, 57, 26);
  background(skyColour);
  fill(groundColour);
  rect(0, height / 2, width, height / 2);
  // Draw a tree
  float treeX = 100;
  float treeY = 180;
  fill(trunkColour);
  rect(treeX, treeY, 20, 70);
  fill(leafColour);
  ellipse(treeX + 10, treeY - 30, 70, 90);
}
