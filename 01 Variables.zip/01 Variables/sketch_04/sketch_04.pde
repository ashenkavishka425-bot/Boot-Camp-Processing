float xPos;           // Sketch-wide scope.

void setup()
{
  size(600, 200);
  fill(0);
  textSize(48);
  xPos = width;       // Start text off the right edge.
}
void draw()
{
  background(255);
  text("Hello Bootcamp...", xPos, height / 2);
  xPos = xPos - 1;    // Move 1 pixel left each frame.
}
