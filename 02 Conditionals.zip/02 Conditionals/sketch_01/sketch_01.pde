void setup()
{
  size(400, 300);
  fill(203, 118, 122);
}

void draw()
{
  background(255, 236, 149);
  rect(mouseX, mouseY, 120, 80);
}
