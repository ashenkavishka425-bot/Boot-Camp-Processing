float xPos;
float vx;
float radius;

void setup()
{
  size(400, 300);
  fill(255, 177, 8);
  xPos = width/2;
  vx = -2;
  radius = 50;
}

void draw()
{
  background(64);
  xPos = xPos + vx;
  ellipse(xPos, height/2, radius*2, radius*2);
}
