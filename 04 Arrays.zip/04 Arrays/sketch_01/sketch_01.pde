float diameter0, diameter1, diameter2, diameter3, diameter4;

void setup()
{
  size(400, 200);
  fill(180, 50, 50, 100);
  noStroke();
  diameter0 = 21; diameter1 = 48; diameter2 = 60;
  diameter3 = 36; diameter4 = 23;
}

void draw()
{
  background(255);
  float xPos = 50;
  ellipse(xPos, 100, diameter0, diameter0); xPos += 70;
  ellipse(xPos, 100, diameter1, diameter1); xPos += 70;
  ellipse(xPos, 100, diameter2, diameter2); xPos += 70;
  ellipse(xPos, 100, diameter3, diameter3); xPos += 70;
  ellipse(xPos, 100, diameter4, diameter4);
}
