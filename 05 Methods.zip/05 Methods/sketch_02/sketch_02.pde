void checkForPegCollision(float x, float y)
{
  if (dist(xPos, yPos, x, y) < radius + pegRadius)
  {
    fill(0);
    textAlign(CENTER, CENTER);
    text("GAME OVER!", width/2, height/2);
    frameRate(0);
  }
}

void draw()
{
  background(255);

  drawPeg(peg1X, peg1Y);
  drawPeg(peg2X, peg2Y);
  drawPeg(peg3X, peg3Y);

  if (inPlayMode)
  {
    moveBall();
    drawBall();
    bounceOffWalls();
    checkForPegCollision(peg1X, peg1Y);
    checkForPegCollision(peg2X, peg2Y);
    checkForPegCollision(peg3X, peg3Y);
  }
  else
  {
    drawBall();
    drawAimingLine();
  }
}
