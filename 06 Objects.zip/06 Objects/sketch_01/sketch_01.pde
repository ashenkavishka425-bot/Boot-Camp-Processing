String moduleTitle = "Coding bootcamp";
println(moduleTitle);               // Coding bootcamp
println(moduleTitle.length());      // 15
println(moduleTitle.toUpperCase()); // CODING BOOTCAMP
println(moduleTitle.substring(7));  // bootcamp

if (moduleTitle.contains("boot")) { println("Found it!"); }
if (moduleTitle.equalsIgnoreCase("CODING BOOTCAMP")) { println("Match!"); }
