class Ball
{
  // Fields — the data this object stores
  float x, y;
  float vx, vy;
  float radius;
  color col;

  // Constructor — called when we write new Ball(...)
  Ball(float startX, float startY, float r)
  {
    x = startX;
    y = startY;
    vx = random(-3, 3);
    vy = random(-3, 3);
    radius = r;
    col = color(random(255), random(255), random(255));
  }

  // Method — update position and bounce
  void update()
  {
    x += vx;
    y += vy;
    if (x - radius < 0 || x + radius > width)  vx = -vx;
    if (y - radius < 0 || y + radius > height) vy = -vy;
  }

  // Method — draw the ball
  void display()
  {
    fill(col);
    noStroke();
    ellipse(x, y, radius * 2, radius * 2);
  }
}
