Ball myBall;

void setup()
{
  size(400, 300);
  myBall = new Ball(200, 150, 25);  // Create one Ball object
}

void draw()
{
  background(30);
  myBall.update();   // Call the method on the object
  myBall.display();
}
