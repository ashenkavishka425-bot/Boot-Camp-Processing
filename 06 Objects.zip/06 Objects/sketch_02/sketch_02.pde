PVector position;
PVector velocity;

void setup()
{
  size(400, 300);
  position = new PVector(200, 150);  // Create an object with new
  velocity = new PVector(2, 1.5);
}

void draw()
{
  background(240);
  position.add(velocity);            // Call a method on the object

  // Access the fields (x, y) with the dot operator
  if (position.x < 0 || position.x > width)  velocity.x *= -1;
  if (position.y < 0 || position.y > height) velocity.y *= -1;

  ellipse(position.x, position.y, 30, 30);
}
