ArrayList<Ball> balls = new ArrayList<Ball>();

void mousePressed()
{
  balls.add(new Ball(mouseX, mouseY, random(10, 30)));
}

void draw()
{
  background(30);
  for (Ball b : balls) { b.update(); b.display(); }
}
