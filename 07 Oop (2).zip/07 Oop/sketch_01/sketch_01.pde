class Ball
{
  private float radius;  // Private — cannot be accessed directly from outside

  Ball(float r)
  {
    radius = r;
  }

  // Getter — read the value safely
  float getRadius()
  {
    return radius;
  }

  // Setter — update the value with validation
  void setRadius(float r)
  {
    if (r > 0) { radius = r; }  // Reject invalid values
  }
}
