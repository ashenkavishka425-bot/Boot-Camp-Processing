// Parent class
class Shape
{
  float x, y;
  color fillColour;

  Shape(float x, float y, color c)
  {
    this.x = x;
    this.y = y;
    fillColour = c;
  }

  void display()
  {
    fill(fillColour);
    noStroke();
  }

  void move(float dx, float dy)
  {
    x += dx;
    y += dy;
  }
}
