Shape[] shapes;

void setup()
{
  size(500, 400);
  shapes = new Shape[4];
  shapes[0] = new Circle(100, 100, color(220, 80, 80), 40);
  shapes[1] = new Rectangle(250, 150, color(80, 150, 220), 80, 50);
  shapes[2] = new Circle(380, 200, color(80, 220, 120), 30);
  shapes[3] = new Rectangle(150, 300, color(220, 200, 80), 60, 40);
}

void draw()
{
  background(245);
  for (Shape s : shapes)
  {
    s.display();        // Calls Circle.display() or Rectangle.display() as appropriate
    s.move(0.5, 0.3);  // Inherited from Shape — same for all
  }
}
