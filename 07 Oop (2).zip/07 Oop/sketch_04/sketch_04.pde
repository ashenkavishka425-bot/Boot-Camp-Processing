GameEntity (parent)
  fields: x, y, colour
  methods: display(), update(), isOffScreen()

  Enemy extends GameEntity
    fields: speed
    methods: display() [override], update() [override]

  Player extends GameEntity
    fields: lives
    methods: display() [override], shoot()

  Projectile extends GameEntity
    fields: vx, vy
    methods: update() [override]
