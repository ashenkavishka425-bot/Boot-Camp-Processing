int counter = 0;

void setup()
{
  size(300, 300);
  textSize(36);
}

void draw()
{
  background(254, 232, 134);
  fill(0);
  text(counter, width/2, height/2);
}

void mouseClicked()
{
  counter = counter + 1;
}
