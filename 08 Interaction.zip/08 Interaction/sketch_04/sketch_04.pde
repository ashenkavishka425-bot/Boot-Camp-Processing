void setup()
{
  size(400, 400);
  background(240);
  strokeWeight(4);
  stroke(0);
}

void draw()
{
  if (mousePressed)
  {
    line(pmouseX, pmouseY, mouseX, mouseY);
  }
}
