String welcomeMessage = "Type the password...";
String successMessage = "Welcome. Shall we play a game?";
String retryMessage   = "Incorrect password. Please try again.";
String currentMessage;

void setup()
{
  size(400, 60);
  textSize(16);
  currentMessage = welcomeMessage;
}

void draw()
{
  background(100);
  fill(255);
  text(currentMessage, 20, 35);
}
