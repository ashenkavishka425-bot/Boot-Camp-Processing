PImage[] sprite = new PImage[8];

void setup()
{
  size(400, 300);
  for (int i = 0; i < 8; i = i + 1)
  {
    sprite[i] = loadImage("man" + i + ".png");
  }
}

void draw()
{
  background(200);
  int frame = (millis() / 100) % 8;  // Cycle through frames
  image(sprite[frame], mouseX, mouseY);
}
