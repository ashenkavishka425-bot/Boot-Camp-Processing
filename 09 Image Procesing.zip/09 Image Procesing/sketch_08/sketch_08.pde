PImage img;

void setup() { size(640, 480); img = loadImage("Holiday.png"); rectMode(CENTER); background(127); }

void draw()
{
  color c = img.get(mouseX, mouseY);  // Sample image pixel under mouse
  fill(c);
  rect(mouseX, mouseY, 25, 25);
}
