String[] textLines;
int lineToDisplay;

void setup()
{
  size(600, 400);
  textLines = loadStrings("theTimeMachine.txt");
  lineToDisplay = 142;
  textSize(14);  fill(0);
}

void draw()
{
  background(255);

  
  
}

void keyPressed()
{
  if ((key == '<') && (lineToDisplay > 0))
    lineToDisplay--;
  else if ((key == '>') && (lineToDisplay < textLines.length-1))
    lineToDisplay++;
  else if (key == ' ')
    lineToDisplay = 10;  // Title line
}
