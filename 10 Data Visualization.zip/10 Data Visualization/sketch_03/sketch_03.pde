String someText = "BootCamp is a fantastic experience";
String[] splitText = split(someText, ' ');  // Split on spaces
for (int i = 0; i < splitText.length; i = i + 1)
{
  println(i + " > " + splitText[i]);
}
