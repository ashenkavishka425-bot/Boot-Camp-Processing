String textLine = "The night came like the turning out of a lamp...";

void draw()
{
  background(255);
  float yPos = 18;
  String[] tokens = split(textLine, " ");
  for (String token : tokens)
  {
    fill(random(50,200), random(50,200), random(50,200));
    text(token, 10, yPos);
    yPos = yPos + 12;
  }
  noLoop();
}
