String textLine = "14,16,18,19,19";  // Daily max temperatures

void draw()
{
  background(255);
  float xPos = 30;
  String[] tokens = split(textLine, ",");
  for (String token : tokens)
  {
    float temperature = float(token);  // Convert text to number
    rect(xPos, 100, 65, temperature);
    xPos = xPos + 70;
  }
}
