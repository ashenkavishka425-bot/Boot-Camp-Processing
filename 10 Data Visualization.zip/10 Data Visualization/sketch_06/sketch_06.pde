String[] stations;
int[] availableBikes;
int[] capacities;

void setup()
{
  size(600, 405);
  textAlign(LEFT, TOP);
  String[] textLines = loadStrings("bikeShare.txt");

  stations       = new String[textLines.length];
  availableBikes = new int[textLines.length];
  capacities     = new int[textLines.length];

  for (int i = 1; i < textLines.length; i = i + 1)
  {
    String[] values = split(textLines[i], ",");
    stations[i]       = values[1];
    availableBikes[i] = int(values[23]);  // Column 23 = 9am
    capacities[i]     = int(values[4]);
  }
}

void draw()
{
  background(255);
  float yPos = 2;
  for (int i = 1; i <= 25; i = i + 1)
  {
    fill(0);
    text(stations[i], 5, yPos);
    noStroke();
    fill(50, 50, 200, 100);
    rect(220, yPos+1, availableBikes[i]*8, 14);
    noFill();  stroke(0);
    rect(220, yPos+1, capacities[i]*8, 14);
    yPos += 16;
  }
}
