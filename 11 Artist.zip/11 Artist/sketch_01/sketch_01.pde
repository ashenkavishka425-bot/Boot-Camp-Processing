// Smooth random movement with noise()
float xPos = map(noise(frameCount * 0.01, 1), 0, 1, 0, width);
float yPos = map(noise(frameCount * 0.01, 2), 0, 1, 0, height);
ellipse(xPos, yPos, 30, 30);
