import processing.sound.*;

SoundFile kick, snare, hiHat;

void setup()
{
  size(300, 200);
  kick  = new SoundFile(this, "kickDrum.wav");
  snare = new SoundFile(this, "snareDrum.wav");
  hiHat = new SoundFile(this, "hihat.wav");
}

void draw() { noLoop(); }

void keyPressed()
{
  if (key == ' ')     kick.play();
  else if (key == 's') snare.play();
  else if (key == 'h') hiHat.play();
}
