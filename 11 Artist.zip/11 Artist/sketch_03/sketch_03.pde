import processing.sound.*;

SoundFile song;
boolean isPlaying;

void setup()
{
  size(400, 250);
  textSize(36);  textAlign(CENTER, CENTER);
  song = new SoundFile(this, "loop7.mp3");
  song.play();  isPlaying = true;
}

void draw()
{
  background(0);
  text(isPlaying ? "Playing" : "Paused", width/2, height/2);
}

void keyPressed()
{
  if (key == ' ')
  {
    if (isPlaying) { song.pause(); isPlaying = false; }
    else           { song.play();  isPlaying = true;  }
  }
}
