import processing.sound.*;

FFT fft;
int NUM_BANDS = 256;
float baseLine;

void setup()
{
  size(532, 250);
  background(4, 60, 5);
  baseLine = 20;
  SoundFile sound = new SoundFile(this, "loop7.mp3");
  sound.play();
  fft = new FFT(this, NUM_BANDS);
  fft.input(sound);
}

void draw()
{
  noStroke();  fill(4, 60, 5, 5);  rect(0, 0, width, height);
  stroke(142, 187, 82);  strokeWeight(2);
  fft.analyze();
  beginShape();
  for (int i = 0; i < fft.spectrum.length * 0.4; i = i + 1)
  {
    float xPos = map(i, 0, fft.spectrum.length*0.4, 10, width-10);
    float yPos = map(sqrt(fft.spectrum[i]), 0, 1, baseLine, baseLine-height*0.7);
    vertex(xPos, yPos);
  }
  endShape();
  baseLine++;
  if (baseLine > height-10) baseLine = 20;
}
