import processing.video.*;

Movie myVideo;

void setup()
{
  size(640, 360);
  myVideo = new Movie(this, "HelloWorldClip.mov");
  myVideo.play();
}

void draw()
{
  image(myVideo, 0, 0);  // Draw at position (0,0), natural size
}

void movieEvent(Movie videoBuffer)
{
  videoBuffer.read();  // Required — reads the next video frame
}
