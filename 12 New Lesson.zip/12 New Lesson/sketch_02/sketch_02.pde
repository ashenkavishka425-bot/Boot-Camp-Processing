void draw()
{
  background(0);
  translate(width/2, height/2, 0);  // Move origin to canvas centre
  fill(255, 0, 0);
  noStroke();
  sphere(150);
}
