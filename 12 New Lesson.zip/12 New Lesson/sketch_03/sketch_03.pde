// A box viewed from a corner
translate(width/2, height/2, 0);
rotateX(radians(-30));
rotateY(radians(45));
box(200);           // Cube

// Or a rectangular box
box(200, 150, 100);  // width, height, depth
