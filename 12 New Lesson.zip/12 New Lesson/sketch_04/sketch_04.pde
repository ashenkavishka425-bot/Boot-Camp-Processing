// Ellipsoid rotating around its own centre, shifted right
float angle;

void draw()
{
  background(252, 239, 232);
  noFill();  stroke(147, 86, 55);
  translate(width/2, height/2, 0);   // Centre the view
  translate(150, 0, 0);              // Shift right
  rotateY(radians(angle));           // Spin around its own centre
  scale(1, 2, 1);                    // Stretch along y-axis
  sphere(100);
  angle = angle + 1;
}
