float angle;

void draw()
{
  background(252, 239, 232);
  noFill();  stroke(147, 86, 55);
  translate(width/2, height/2, 0);

  pushMatrix();                     // Save state
    translate(150, 0, 0);
    rotateY(radians(angle));
    scale(1, 2, 1);
    sphere(100);                    // First sphere
  popMatrix();                      // Restore state

  pushMatrix();                     // Save again
    translate(-130, 0, 0);
    rotateX(radians(angle));
    scale(1, 2, 1);
    sphere(100);                    // Second sphere
  popMatrix();

  angle = angle + 1;
}
