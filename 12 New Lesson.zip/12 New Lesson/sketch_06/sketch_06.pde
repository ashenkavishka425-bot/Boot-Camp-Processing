void draw()
{
  background(255);
  lights();                        // Enable default lighting
  translate(width/2, height/2, 0);
  fill(255, 0, 0);
  sphere(150);
}
