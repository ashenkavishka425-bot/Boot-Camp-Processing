lightSpecular(200, 200, 200);       // Specular colour of the light
specular(255, 255, 255);            // How much specular light the surface reflects
shininess(25);                      // Glossiness (0–255)
float hw = width/2, hh = height/2;
directionalLight(255, 255, 255, -(mouseX-hw)/hw, -(mouseY-hh)/hh, -1);
