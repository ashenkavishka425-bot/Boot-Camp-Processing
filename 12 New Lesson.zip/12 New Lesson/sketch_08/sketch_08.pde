// Tetrahedron (4 triangles)
void draw()
{
  background(0);  fill(255);
  translate(width/2, height/2, 190);
  rotateX(radians(-mouseY - height/2));
  rotateY(radians(mouseX - width/2));

  beginShape(TRIANGLES);
    vertex(0,    0,    100);
    vertex(-100, 100,  0);
    vertex(100,  100,  0);

    vertex(0,    0,    100);
    vertex(100,  100,  0);
    vertex(0,   -100,  0);

    vertex(0,    0,    100);
    vertex(0,   -100,  0);
    vertex(-100, 100,  0);

    vertex(-100, 100,  0);
    vertex(100,  100,  0);
    vertex(0,   -100,  0);
  endShape();
}
