PImage img;

void setup() { size(640, 480, P3D); img = loadImage("lovelace.jpg"); }

void draw()
{
  background(255);
  translate(width/2, height/2, -200);
  rotateX(radians(mouseY));
  int d = 16;  float s = 0.003;  float t = millis()/5000.0;

  for (int x = 0; x < width; x += d)
  {
    for (int y = 0; y < height; y += d)
    {
      float z1 = (noise(x*s, y*s, t) - 0.5) * width;
      float z2 = (noise((x+d)*s, y*s, t) - 0.5) * width;
      float z3 = (noise((x+d)*s, (y+d)*s, t) - 0.5) * width;
      float z4 = (noise(x*s, (y+d)*s, t) - 0.5) * width;

      beginShape(QUADS);
        textureMode(NORMAL);
        texture(img);
        vertex(x-width/2,     y-height/2,   z1, x/float(width),     y/float(height));
        vertex(x+d-width/2,   y-height/2,   z2, (x+d)/float(width), y/float(height));
        vertex(x+d-width/2, y+d-height/2,   z3, (x+d)/float(width), (y+d)/float(height));
        vertex(x-width/2,   y+d-height/2,   z4, x/float(width),     (y+d)/float(height));
      endShape();
    }
  }
}
